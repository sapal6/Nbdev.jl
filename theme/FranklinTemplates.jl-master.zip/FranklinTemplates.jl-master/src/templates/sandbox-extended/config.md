@def author = "The Oracle"

@def hasplotly = false
@def hasmdpad = false

@def generate_rss = false
